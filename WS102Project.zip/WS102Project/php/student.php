<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Responsive Sidebar with Sections</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
            transition: transform 0.3s ease-in-out;
        }
        .section-content.active {
            display: block;
        }
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.show {
                transform: translateX(0);
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                <div class="position-sticky pt-3">
                    <!-- User Management Navigation -->
                    <h6 class="sidebar-heading px-3 mt-4 mb-1 text-muted">
                        User Management
                    </h6>
                    <ul class="nav flex-column mb-3">
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-section="user-profile">
                                <i class="bi bi-person"></i> User Profile
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-section="account-settings">
                                <i class="bi bi-gear"></i> Account Settings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-section="security">
                                <i class="bi bi-shield-lock"></i> Security
                            </a>
                        </li>
                    </ul>

                    <!-- System Management Navigation -->
                    <h6 class="sidebar-heading px-3 mt-4 mb-1 text-muted">
                        System Management
                    </h6>
                    <ul class="nav flex-column mb-3">
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-section="dashboard">
                                <i class="bi bi-speedometer2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-section="reports">
                                <i class="bi bi-file-earmark-text"></i> Reports
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-section="logs">
                                <i class="bi bi-journal-code"></i> System Logs
                            </a>
                        </li>
                    </ul>

                    <!-- Analytics Navigation -->
                    <h6 class="sidebar-heading px-3 mt-4 mb-1 text-muted">
                        Analytics
                    </h6>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-section="performance">
                                <i class="bi bi-graph-up"></i> Performance
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-section="user-insights">
                                <i class="bi bi-people"></i> User Insights
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-section="revenue">
                                <i class="bi bi-cash-coin"></i> Revenue
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <button class="btn btn-primary d-md-none my-3" type="button" data-bs-toggle="collapse" data-bs-target=".sidebar">
                    Toggle Sidebar
                </button>

                <!-- Sections Content -->
                <div id="user-profile" class="section-content">
                    <h2>User Profile</h2>
                    <div class="card">
                        <div class="card-body">
                            <h5>Profile Management</h5>
                            <p>Manage your personal information and preferences.</p>
                        </div>
                    </div>
                </div>

                <div id="account-settings" class="section-content">
                    <h2>Account Settings</h2>
                    <div class="card">
                        <div class="card-body">
                            <h5>Configure Account</h5>
                            <p>Adjust your account preferences and settings.</p>
                        </div>
                    </div>
                </div>

                <div id="security" class="section-content">
                    <h2>Security</h2>
                    <div class="card">
                        <div class="card-body">
                            <h5>Security Settings</h5>
                            <p>Manage password, two-factor authentication, and privacy.</p>
                        </div>
                    </div>
                </div>

                <div id="dashboard" class="section-content">
                    <h2>Dashboard</h2>
                    <div class="card">
                        <div class="card-body">
                            <h5>System Overview</h5>
                            <p>Quick insights and system status.</p>
                        </div>
                    </div>
                </div>

                <div id="reports" class="section-content">
                    <h2>Reports</h2>
                    <div class="card">
                        <div class="card-body">
                            <h5>Generate Reports</h5>
                            <p>Create and download various system reports.</p>
                        </div>
                    </div>
                </div>

                <div id="logs" class="section-content">
                    <h2>System Logs</h2>
                    <div class="card">
                        <div class="card-body">
                            <h5>Log Management</h5>
                            <p>View and analyze system logs.</p>
                        </div>
                    </div>
                </div>

                <div id="performance" class="section-content">
                    <h2>Performance Analytics</h2>
                    <div class="card">
                        <div class="card-body">
                            <h5>System Performance</h5>
                            <p>Detailed performance metrics and trends.</p>
                        </div>
                    </div>
                </div>

                <div id="user-insights" class="section-content">
                    <h2>User Insights</h2>
                    <div class="card">
                        <div class="card-body">
                            <h5>User Activity</h5>
                            <p>Analyze user behavior and engagement.</p>
                        </div>
                    </div>
                </div>

                <div id="revenue" class="section-content">
                    <h2>Revenue Analytics</h2>
                    <div class="card">
                        <div class="card-body">
                            <h5>Financial Overview</h5>
                            <p>Track and analyze revenue streams.</p>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const navLinks = document.querySelectorAll('.nav-link');
            const sections = document.querySelectorAll('.section-content');

            navLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const sectionId = this.getAttribute('data-section');

                    // Hide all sections
                    sections.forEach(section => {
                        section.classList.remove('active');
                    });

                    // Show selected section
                    document.getElementById(sectionId).classList.add('active');
                });
            });
        });
    </script>
</body>
</html>