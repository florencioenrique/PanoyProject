<?php
    include "../includes/config.php";

    session_start();

    // Log in for admin
    if (isset($_POST['login'])) {
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);

        // SQL query to check username and password
        $sql = "SELECT * FROM admin WHERE username = ? AND password = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ss', $username, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $_SESSION['admin_name'] = $row['name'];
            $_SESSION['admin_id'] = $row['id'];

            header('Location: admin.php');
            exit();
        } else {
            echo "Invalid username or password.";
        }
        $stmt->close();
    }

    // Adding new faculty
    if (isset($_POST['newFaculty'])) {
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $gender = $_POST['gender'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        $stmt = $conn->prepare("INSERT INTO faculty (firstname, lastname, sex, email, password) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param('sssss', $firstname, $lastname, $gender, $email, $password);
        $stmt->execute();

        if ($stmt->error) {
            header('Location: admin.php?status=error');
        } else {
            header('Location: admin.php?status=success');
        }
    }

    if (isset($_POST['newStudent'])) {
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $gender = $_POST['gender'];
        $level = $_POST['level'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        $stmt = $conn->prepare("INSERT INTO student (firstname, lastname, sex, year, email, password) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('ssssss', $firstname, $lastname, $gender, $level, $email, $password);
        $stmt->execute();

        if ($stmt->error) {
            header('Location: admin.php?status=error');
        } else {
            header('Location: admin.php?status=success');
        }
    }

    if (isset($_POST['addCourses'])) {
        $courseId = $_POST['course_id'];
        $courseName = $_POST['course_name'];

        $stmt = $conn->prepare("INSERT INTO course (course_id, course_name) VALUES (?, ?)");
        $stmt->bind_param('ss', $courseId, $courseName);
        $stmt->execute();

        if ($stmt->error) {
            echo "Something went wrong";
        } else {
            echo "Something went right";
            header("Location: admin.php");
        }
    }

    if (isset($_POST['admin_update_btn'])) {
        $updated_admin_name = $_POST['admin_name'];
        $admin_id = $_POST['admin_id'];

        if (!empty($updated_admin_name)) {
            $stmt = $conn->prepare("UPDATE admin SET name = ? WHERE id = ?");
            if (!$stmt) {
                die('Prepare failed: ' . $conn->error);
            }

            $stmt->bind_param('si', $updated_admin_name, $admin_id);
            
            if ($stmt->execute()) {
                $_SESSION['admin_name'] = $updated_admin_name;
                header('Location: admin.php?update=success');
                exit();
            } else {
                die('Execute failed: ' . $stmt->error);
            }

            $stmt->close();
        } else {
            header('Location: admin.php?status=empty');
            exit();
        }
    }


    if (isset($_POST['logoutbtn'])) {
        session_unset();

        session_destroy();

        header('Location: index.php');
        exit();
    }
?>
