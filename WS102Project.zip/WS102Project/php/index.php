<!DOCTYPE html>
<html lang="en">
<head>
    <?php
        include "../includes/head.php";
    ?>
</head>
<body class="index_body">
    <div class="container">
        <div class="row login-container">
            <div class="col-md-6 logo-section">
                <h2 class="text-center mb-4 index_greetings">Welcome Cyberian</h2>
                <img src="../static/images/IT_logo.jpg" class="img-fluid" alt="IT Logo">
            </div>
            <div class="col-md-6 login-section">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title text-center mb-4" style="color: var(--primary-color);">Login</h3>
                        <form action="dbconnect.php" method="POST">
                            <div class="mb-3">
                                <label for="role" class="form-label">Select Role</label>
                                <select id="role" name="role" class="form-control" required>
                                    <option value="student">Student</option>
                                    <option value="staff">Staff</option>
                                    <option value="admin">Admin</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" id="username" name="username" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" id="password" name="password" class="form-control" required>
                            </div>
                            <div class="d-grid">
                                <button type="submit" name="login" class="btn btn-primary">Login</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
